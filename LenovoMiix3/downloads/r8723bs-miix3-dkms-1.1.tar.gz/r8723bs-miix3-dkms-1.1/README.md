# RTL8723BS Lenovo MIIX 3-1030 DKMS module

Version 1.1 packages the exact v14 transfer path that passed the MIIX 3-1030
stress tests. The only removed code is the disabled, diagnostic-only direct
SDHCI PIO switch, which depended on a private in-tree header and was not part of
the working configuration.

The active workarounds are:

- clear `SDIO_SPEED_EHS` before Realtek I/O and use legacy 25 MHz timing;
- use CMD52 for aligned 32-bit register writes while retaining CMD53 for data;
- retain the fixed-address RX and incrementing-address TX behavior from the
  proven v8/v14 module.

## Install

Extract the archive, enter the extracted directory, and run:

```sh
sudo bash install.sh
sudo reboot
```

The installer adds the module to DKMS, builds it for the running kernel,
installs the minimal modprobe configuration, and rebuilds the initramfs. DKMS
will automatically attempt to build it whenever a new kernel and matching
headers are installed.

After a kernel upgrade, check `dkms status` before rebooting. A future kernel
API change can still cause a DKMS build failure; retain the previous known-good
kernel as a fallback until Wi-Fi has been verified on the new kernel.

Do not unload/reload `r8723bs` on a running affected tablet. Install for the
next boot and reboot cleanly.
