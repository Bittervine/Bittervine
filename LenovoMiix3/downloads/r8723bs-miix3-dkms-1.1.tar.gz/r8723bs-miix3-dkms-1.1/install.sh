#!/usr/bin/env bash
set -euo pipefail

package_name="r8723bs-miix3"
package_version="1.1"
kernel_version="${1:-$(uname -r)}"
source_dir="/usr/src/${package_name}-${package_version}"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ ${EUID} -ne 0 ]]; then
	echo "Run this installer as root: sudo bash install.sh" >&2
	exit 2
fi

if [[ -e ${source_dir} ]]; then
	echo "Refusing to overwrite existing ${source_dir}" >&2
	exit 2
fi

if dkms status -m "${package_name}" -v "${package_version}" 2>/dev/null | grep -q .; then
	echo "DKMS package ${package_name}/${package_version} is already registered" >&2
	exit 2
fi

echo "Installing build prerequisites for kernel ${kernel_version}..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
	dkms "linux-headers-${kernel_version}"

echo "Registering ${package_name}/${package_version} with DKMS..."
install -d -m 0755 "${source_dir}"
cp -a "${script_dir}/." "${source_dir}/"
dkms add -m "${package_name}" -v "${package_version}"
dkms build -m "${package_name}" -v "${package_version}" -k "${kernel_version}"
dkms install -m "${package_name}" -v "${package_version}" -k "${kernel_version}"

if [[ -e /etc/modprobe.d/r8723bs-cmd52.conf ]]; then
	cp -a /etc/modprobe.d/r8723bs-cmd52.conf \
		/etc/modprobe.d/r8723bs-cmd52.conf.pre-dkms
fi
install -m 0644 "${script_dir}/r8723bs-miix3.conf" \
	/etc/modprobe.d/r8723bs-cmd52.conf

depmod -a "${kernel_version}"
update-initramfs -u -k "${kernel_version}"

echo
echo "Installed module: $(modinfo -k "${kernel_version}" -n r8723bs)"
echo "DKMS status:"
dkms status -m "${package_name}" -v "${package_version}"
echo
echo "Do not unload/reload r8723bs on the running system. Reboot cleanly."
